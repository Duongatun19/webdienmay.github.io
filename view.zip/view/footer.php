<link rel="stylesheet" href="./css/footer.css">
<link rel="stylesheet" href="./css/reposive.css">
<div class="hr"></div>
<div class="bottom">
<div class="container">
<div class="layuot_tt">
<div class="item_tt">
<div class="icon">
<img src="./images/company.png" alt="" width="90px" height="90px">
</div>
<div class="title_bt">Trụ Sở</div>
<div class="nd_bt">Tân Phú- Tân Sơn- Phú Thọ</div>



</div>
<!-- ------------------------ -->
<div class="item_tt">
<div class="icon">
<img src="./images/hotline.png" alt="" width="90px" height="90px" style="  border-radius: 0px;">
</div>
<div class="title_bt">Tư vấn</div>
<div class="nd_bt">Mobile:0987654321</div>



</div>
<!-- ------------------ -->
<div class="item_tt">
<div class="icon">
    <img src="./images/email.png" alt="" width="90px" height="90px">
</div>
<div class="title_bt">Hỗ Trợ</div>
<div class="nd_btt" >Email:<a href="https://www.google.com/gmail/about/" style="color: orange;">duongatun19@gmail.com</a></div>

<!-- ------------------- -->

</div>
<div class="item_tt1">
<div class="icon anhbottom">
    <a href="https://duongatun19.github.io/"><img class="tuanimg" src="./images/tuan.jpg" alt="" ></a>
   
</div>
<div class="title_bt">Design</div>
<div class="nd_bt" ><a href="" style="color: bisque;">Dương Tuấn</a></div>
</div>

</div>
</div>
</div>
</body>
</html>