<link rel="stylesheet" href="./css/slide_Bar.css">
<link rel="stylesheet" href="./css/reposive.css">

<div id="slideshow">
  <div class="slide-wrapper">
    <div class="slide"><img src="./images/slide1.jpg" style="width: 1920px; height:550px"></div>
    <div class="slide"><img src="./images/slide3.jpg" style="width: 1920px; height:550px"></div>
       <div class="slide"><img src="./images/slide5.jpg" style="width: 1920px; height:550px"></div>
  </div>
</div>


